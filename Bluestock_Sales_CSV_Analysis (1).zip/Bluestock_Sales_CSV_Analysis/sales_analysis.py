import pandas as pd
import matplotlib.pyplot as plt

# Load CSV
df = pd.read_csv("sales_raw.csv")
print("Raw rows and columns:", df.shape)

# Clean data
df = df.drop_duplicates()
for col in ["Product", "Category", "Region", "Customer_ID"]:
    df[col] = df[col].astype("string").str.strip()
df["Product"] = df["Product"].str.title()
df["Region"] = df["Region"].str.title()
df["Category"] = df["Category"].str.title()
df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")
for col in ["Quantity", "Unit_Price", "Sales"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")
df = df.dropna(subset=["Order_ID", "Order_Date", "Product", "Quantity", "Unit_Price", "Region"])
df = df[(df["Quantity"] > 0) & (df["Unit_Price"] > 0)]
df["Sales"] = (df["Quantity"] * df["Unit_Price"]).round(2)
df.to_csv("sales_cleaned.csv", index=False)

# KPIs
revenue = df["Sales"].sum()
orders = df["Order_ID"].nunique()
units = df["Quantity"].sum()
aov = revenue / orders if orders else 0
customers = df["Customer_ID"].nunique()
print(f"Total Revenue: ₹{revenue:,.2f}")
print(f"Total Orders: {orders}")
print(f"Units Sold: {units:,.0f}")
print(f"Average Order Value: ₹{aov:,.2f}")
print(f"Unique Customers: {customers}")

# Charts
df["Month"] = df["Order_Date"].dt.to_period("M").astype(str)
df.groupby("Month")["Sales"].sum().plot(kind="line", marker="o", title="Monthly Sales Revenue")
plt.xlabel("Month"); plt.ylabel("Revenue (INR)"); plt.tight_layout()
plt.savefig("monthly_sales.png"); plt.show()

df.groupby("Region")["Sales"].sum().sort_values(ascending=False).plot(kind="bar", title="Sales by Region")
plt.xlabel("Region"); plt.ylabel("Revenue (INR)"); plt.tight_layout()
plt.savefig("sales_by_region.png"); plt.show()

df.groupby("Product")["Sales"].sum().sort_values(ascending=False).plot(kind="bar", title="Sales by Product")
plt.xlabel("Product"); plt.ylabel("Revenue (INR)"); plt.tight_layout()
plt.savefig("sales_by_product.png"); plt.show()
