Bluestock Sales CSV Analysis

Files:
- sales_raw.csv: sample source data with intentional data-quality issues
- sales_cleaned.csv: cleaned data
- sales_kpis.csv: KPI summary
- sales_analysis.py: reusable Python script
- three PNG files: generated charts

Windows setup:
1. Open this folder in VS Code.
2. Terminal > New Terminal
3. Run: py -m pip install pandas matplotlib
4. Run: py sales_analysis.py

The script expects sales_raw.csv in the same folder.
